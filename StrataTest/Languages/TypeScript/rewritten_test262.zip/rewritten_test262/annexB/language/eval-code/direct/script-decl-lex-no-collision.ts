// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2023 Alexey Shvayka. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-globaldeclarationinstantiation
description: No let binding collision with existing var declaration due to eval().
info: |
  In strict mode:

  PerformEval ( x, strictCaller, direct )

  [...]
  16. If direct is true, then
    a. Let lexEnv be NewDeclarativeEnvironment(runningContext's LexicalEnvironment).
  [...]
  18. If strictEval is true, set varEnv to lexEnv.

  In sloppy mode:

  GlobalDeclarationInstantiation ( script, env )

  [...]
  3. For each element name of lexNames, do
    a. If env.HasLexicalDeclaration(name) is true, throw a SyntaxError exception.
    b. Let hasRestrictedGlobal be ? env.HasRestrictedGlobalProperty(name).
    c. NOTE: Global var and function bindings (except those that are introduced by non-strict direct eval) are non-configurable and are therefore restricted global properties.
    d. If hasRestrictedGlobal is true, throw a SyntaxError exception.
---*/

eval('if (true) { function test262Fn() {} }');

$262.evalScript('let test262Fn = 1;');

assertSameValue(test262Fn, 1);
}
