// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2016 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-escape-string
es6id: B.2.1.1
description: Escaping of code units below 255
info: |
    [...]
    5. Repeat, while k < length,
       a. Let char be the code unit (represented as a 16-bit unsigned integer)
          at index k within string.
       [...]
       d. Else char < 256,
          i. Let S be a String containing three code units "%xy" where xy are
             the code units of two uppercase hexadecimal digits encoding the
             value of char.
       [...]
---*/

assertSameValue(
  escape('\x00\x01\x02\x03'),
  '%00%01%02%03',
  'characters: \\x00\\x01\\x02\\x03'
);

assertSameValue(
  escape('!"#$%&\'()'),
  '%21%22%23%24%25%26%27%28%29',
  'characters preceding "*": !"#$%&\'()'
);

assertSameValue(escape(','), '%2C', 'character between "+" and "-": ,');

assertSameValue(
  escape(':;<=>?'),
  '%3A%3B%3C%3D%3E%3F',
  'characters between "9" and "@": :;<=>?'
);

assertSameValue(
  escape('[\\]^'), '%5B%5C%5D%5E', 'characters between "Z" and "_": [\\]^'
);

assertSameValue(escape('`'), '%60', 'character between "_" and "a": `');

assertSameValue(
  escape('{|}~\x7f\x80'),
  '%7B%7C%7D%7E%7F%80',
  'characters following "z": {|}~\\x7f\\x80'
);

assertSameValue(
  escape('\xfd\xfe\xff'), '%FD%FE%FF', '\\xfd\\xfe\\xff'
);
}
