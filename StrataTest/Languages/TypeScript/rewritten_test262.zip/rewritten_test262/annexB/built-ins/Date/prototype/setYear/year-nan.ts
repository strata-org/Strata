// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2016 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-date.prototype.setyear
es6id: B.2.4.2
es5id: B.2.5
description: Behavior when year value coerces to NaN
info: |
    [...]
    3. Let y be ? ToNumber(year).
    4. If y is NaN, set the [[DateValue]] internal slot of this Date object to
       NaN and return NaN.
features: [Symbol]
---*/

var date;

date = new Date(0);
assertSameValue(date.setYear(), NaN, 'return value (no argument)');
assertSameValue(
  date.valueOf(), NaN, '[[DateValue]] internal slot (no argument)'
);

date = new Date(0);
assertSameValue(date.setYear(NaN), NaN, 'return value (literal NaN)');
assertSameValue(
  date.valueOf(), NaN, '[[DateValue]] internal slot (literal NaN)'
);

date = new Date(0);
assertSameValue(
  date.setYear('not a number'), NaN, 'return value (NaN from ToNumber)'
);
assertSameValue(
  date.valueOf(), NaN, '[[DateValue]] internal slot (NaN from ToNumber)'
);
}
