// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2016 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-date.prototype.setyear
es6id: B.2.4.2
es5id: B.2.5
description: >
    Behavior when the integer representation of the specified `year` is
    relative to 1900
info: |
    [...]
    5. If y is not NaN and 0 ≤ ToInteger(y) ≤ 99, let yyyy be ToInteger(y) +
       1900.
    [...]
---*/

var date;

date = new Date(1970, 0);
date.setYear(-0.9999999);
assertSameValue(date.getFullYear(), 1900, 'y = -0.999999');

date = new Date(1970, 0);
date.setYear(-0);
assertSameValue(date.getFullYear(), 1900, 'y = -0');

date = new Date(1970, 0);
date.setYear(0);
assertSameValue(date.getFullYear(), 1900, 'y = 0');

date = new Date(1970, 0);
date.setYear(50);
assertSameValue(date.getFullYear(), 1950, 'y = 50');

date = new Date(1970, 0);
date.setYear(50.999999);
assertSameValue(date.getFullYear(), 1950, 'y = 50.999999');

date = new Date(1970, 0);
date.setYear(99);
assertSameValue(date.getFullYear(), 1999, 'y = 99');

date = new Date(1970, 0);
date.setYear(99.999999);
assertSameValue(date.getFullYear(), 1999, 'y = 99.999999');
}
