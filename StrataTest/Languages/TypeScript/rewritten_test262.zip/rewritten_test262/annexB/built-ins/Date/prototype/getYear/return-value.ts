// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2016 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-date.prototype.getyear
es6id: B.2.4.1
es5id: B.2.4
description: >
    Return value for objects with numeric value in [[DateValue]] internal slot
info: |
    1. Let t be ? thisTimeValue(this value).
    2. If t is NaN, return NaN.
    3. Return YearFromTime(LocalTime(t)) - 1900.
---*/

assertSameValue(new Date(1899, 0).getYear(), -1, '1899: first millisecond');
assertSameValue(
  new Date(1899, 11, 31, 23, 59, 59, 999).getYear(),
  -1,
  '1899: final millisecond'
);

assertSameValue(new Date(1900, 0).getYear(), 0, '1900: first millisecond');
assertSameValue(
  new Date(1900, 11, 31, 23, 59, 59, 999).getYear(),
  0,
  '1900: final millisecond'
);

assertSameValue(new Date(1970, 0).getYear(), 70, '1970: first millisecond');
assertSameValue(
  new Date(1970, 11, 31, 23, 59, 59, 999).getYear(),
  70,
  '1970: final millisecond'
);

assertSameValue(new Date(2000, 0).getYear(), 100, '2000: first millisecond');
assertSameValue(
  new Date(2000, 11, 31, 23, 59, 59, 999).getYear(),
  100,
  '2000: final millisecond'
);
}
