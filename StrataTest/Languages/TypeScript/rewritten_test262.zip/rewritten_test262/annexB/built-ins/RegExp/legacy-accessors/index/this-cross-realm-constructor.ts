// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2020 ExE Boss. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: pending
description: RegExp.$1-$9 throw a TypeError for cross-realm receiver
info: |
  get RegExp.$1-$9

  1. Return ? GetLegacyRegExpStaticProperty(%RegExp%, this value, [[RegExpParen1-9]]).

  GetLegacyRegExpStaticProperty( C, thisValue, internalSlotName ).

  1. Assert C is an object that has an internal slot named internalSlotName.
  2. If SameValue(C, thisValue) is false, throw a TypeError exception.
  3. ...
features: [legacy-regexp,cross-realm,Reflect]
---*/

const other = $262.createRealm().global;

for (let i = 1; i <= 9; i++) {
  const property = "$" + i;
  assertThrows(
    TypeError,
    function () {
      Reflect.get(RegExp, property, other.RegExp);
    },
    "RegExp." + property + " getter throws for cross-realm receiver"
  );
}
}
