// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright 2017 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/*---
esid: prod-GroupSpecifier
description: >
  \k is parsed as IdentityEscape as look-behind assertion is not a GroupName.
features: [regexp-named-groups, regexp-lookbehind]
---*/

assert(/\k<a>(?<=>)a/.test("k<a>a"));
assert(/(?<=>)\k<a>/.test(">k<a>"));

assert(/\k<a>(?<!a)a/.test("k<a>a"));
assert(/(?<!a>)\k<a>/.test("k<a>"));
}
