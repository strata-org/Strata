// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2020 ExE Boss. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-regexp.prototype.compile
description: RegExp.prototype.compile throws a TypeError for cross-realm calls
features: [legacy-regexp,cross-realm]
---*/

const other = $262.createRealm().global;

const regexp = new RegExp("");
const otherRealm_regexp = new other.RegExp("");

assertThrows(
  TypeError,
  function () {
    RegExp.prototype.compile.call(otherRealm_regexp);
  });

assertThrows(
  other.TypeError,
  function () {
    other.RegExp.prototype.compile.call(regexp);
  },
  "`other.RegExp.prototype.compile.call(regexp)` throws TypeError"
);

assertSameValue(
  otherRealm_regexp.compile(),
  otherRealm_regexp,
  "`otherRealm_regexp.compile()` is SameValue with `otherRealm_regexp`"
);
}
