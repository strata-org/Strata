// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2016 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-regexp.prototype.compile
es6id: B.2.5.1
description: Behavior when "this" value is not an Object
info: |
    1. Let O be the this value.
    2. If Type(O) is not Object or Type(O) is Object and O does not have a
       [[RegExpMatcher]] internal slot, then
       a. Throw a TypeError exception.
features: [Symbol]
---*/

var compile = RegExp.prototype.compile;
var symbol = Symbol('');

assertSameValue(typeof compile, 'function');

assertThrows(TypeError, function () {
  compile.call(undefined);
}, 'undefined');

assertThrows(TypeError, function () {
  compile.call(null);
}, 'null');

assertThrows(TypeError, function () {
  compile.call(23);
}, 'number');

assertThrows(TypeError, function () {
  compile.call(true);
}, 'boolean');

assertThrows(TypeError, function () {
  compile.call('/string/');
}, 'string');

assertThrows(TypeError, function () {
  compile.call(symbol);
}, 'symbol');
}
