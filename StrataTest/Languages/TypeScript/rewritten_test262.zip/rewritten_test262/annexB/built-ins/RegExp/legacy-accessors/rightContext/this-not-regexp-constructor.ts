// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2020 ExE Boss. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: pending
description: RegExp.rightContext throws a TypeError for non-%RegExp% receiver
info: |
  get RegExp.rightContext

  1. Return ? GetLegacyRegExpStaticProperty(%RegExp%, this value, [[RegExpRightContext]]).

  GetLegacyRegExpStaticProperty( C, thisValue, internalSlotName ).

  1. Assert C is an object that has an internal slot named internalSlotName.
  2. If SameValue(C, thisValue) is false, throw a TypeError exception.
  3. ...
features: [legacy-regexp]
---*/

["rightContext", "$'"].forEach(function (property) {
  const desc = Object.getOwnPropertyDescriptor(RegExp, property);

  // Similar to the other test verifying the descriptor, but split as properties can be removed or changed
  assertSameValue(typeof desc.get, "function", property + " getter");

  // If SameValue(C, thisValue) is false, throw a TypeError exception.
  assertThrows(
    TypeError,
    function () {
      desc.get();
    },
    "RegExp." + property + " getter throws for property descriptor receiver"
  );

  assertThrows(
    TypeError,
    function () {
      desc.get.call(/ /);
    },
    "RegExp." + property + " getter throws for RegExp instance receiver"
  );

  assertThrows(
    TypeError,
    function () {
      desc.get.call(RegExp.prototype);
    },
    "RegExp." + property + " getter throws for %RegExp.prototype% receiver"
  );

  [undefined, null, {}, true, false, 0, 1, "string"].forEach(function (value) {
    assertThrows(
      TypeError,
      function () {
        desc.get.call(value);
      },
      "RegExp." + property + ' getter throws for primitive "' + value + '" receiver'
    );
  });
});
}
