// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright 2017 the V8 project authors.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/*---
esid: prod-annexB-ClassAtomNoDash
description: >
  Character classes containing an invalid control escape behave like [\\c]
info: |
  ClassAtomNoDash :: `\`

  The production ClassAtomNoDash :: `\` evaluates as follows:
    1. Return the CharSet containing the single character `\`.
features: [generators]
---*/

function* invalidControls() {
  // Check ASCII characters which are not in the extended range or syntax
  // characters
  for (let alpha = 0x00; alpha <= 0x7F; alpha++) {
    let letter = String.fromCharCode(alpha);
    if (!letter.match(/[0-9A-Za-z_\$(|)\[\]\/\\^]/)) {
      yield letter;
    }
  }
  yield "";
}

for (let letter of invalidControls()) {
  var source = "[\\c" + letter + "]";
  var re = new RegExp(source);

  if (letter.length > 0) {
    var char = letter.charCodeAt(0);
    var str = String.fromCharCode(char % 32);
    var arr = re.exec(str);
    if (str !== letter && arr !== null) {__errorCount++;

    }

    arr = re.exec(letter);
    if (arr === null) {__errorCount++;

    }
  }
  arr = re.exec("\\");
  if (arr === null) {__errorCount++;

  }
  arr = re.exec("c");
  if (arr === null) {__errorCount++;

  }
}
}
