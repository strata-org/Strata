// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright 2009 the Sputnik authors.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/*---
info: |
    RegularExpressionChar :: BackslashSequence :: \NonTerminator,
    RegularExpressionFlags :: [empty]
es5id: 7.8.5_A2.4_T2
es6id: 11.8.5
description: Complex test with eval, using syntax pattern
---*/

for (var cu = 0; cu <= 0xffff; ++cu) {
  var Elimination =
  cu === 0x002A || cu === 0x002F || cu === 0x005C || cu === 0x002B ||
  cu === 0x003F || cu === 0x0028 || cu === 0x0029 ||
  cu === 0x005B || cu === 0x005D || cu === 0x007B || cu === 0x007D;
  /*
       * \u002A     / \u002F     \ \u005C     + \u002B
       ? \u003F     ( \u0028     ) \u0029
       [ \u005B     ] \u005D     { \u007B     } \u007D
  */
  var LineTerminator = cu === 0x000A || cu === 0x000D || cu === 0x2028 || cu === 0x2029;
  if ((Elimination || LineTerminator) === false) {
    var xx = "a\\" + String.fromCharCode(cu);
    var pattern = eval("/" + xx + "/");
    assertSameValue(pattern.source, xx, "Code unit: " + cu.toString(16));
  }
}
}
