// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2016 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-unescape-string
es6id: B.2.1.2
description: >
    Does not transform two-character patterns that are interrupted by the end
    of the string
info: |
    [...]
    5. Repeat, while k ≠ length,
       [...]
       a. Let c be the code unit at index k within string.
       b. If c is %, then
          [...]
          ii. Else if k ≤ length-3 and the two code units at indices k+1 and
              k+2 within string are both hexadecimal digits, then
              1. Let c be the code unit whose value is the integer represented
                 by two zeroes plus the two hexadecimal digits at indices k+1
                 and k+2 within string.
              2. Increase k by 2.
       [...]
---*/

assertSameValue(unescape('%'), '%');
assertSameValue(unescape('%0'), '%0');
assertSameValue(unescape('%1'), '%1');
assertSameValue(unescape('%2'), '%2');
assertSameValue(unescape('%3'), '%3');
assertSameValue(unescape('%4'), '%4');
assertSameValue(unescape('%5'), '%5');
assertSameValue(unescape('%6'), '%6');
assertSameValue(unescape('%7'), '%7');
assertSameValue(unescape('%8'), '%8');
assertSameValue(unescape('%9'), '%9');
assertSameValue(unescape('%a'), '%a');
assertSameValue(unescape('%A'), '%A');
assertSameValue(unescape('%b'), '%b');
assertSameValue(unescape('%B'), '%B');
assertSameValue(unescape('%c'), '%c');
assertSameValue(unescape('%C'), '%C');
assertSameValue(unescape('%d'), '%d');
assertSameValue(unescape('%D'), '%D');
assertSameValue(unescape('%e'), '%e');
assertSameValue(unescape('%E'), '%E');
assertSameValue(unescape('%f'), '%f');
assertSameValue(unescape('%F'), '%F');
}
