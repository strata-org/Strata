// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2016 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-unescape-string
es6id: B.2.1.2
description: >
    Does not transform four-character patterns that contain non-hexadecimal
    digits
info: |
    [...]
    5. Repeat, while k ≠ length,
       [...]
       a. Let c be the code unit at index k within string.
       b. If c is %, then
          i. If k ≤ length-6 and the code unit at index k+1 within string is u
             and the four code units at indices k+2, k+3, k+4, and k+5 within
             string are all hexadecimal digits, then
             1. Let c be the code unit whose value is the integer represented
                by the four hexadecimal digits at indices k+2, k+3, k+4, and
                k+5 within string.
             2. Increase k by 5.
       [...]
---*/

assertSameValue(unescape('%u000%0'), '%u000%0');

assertSameValue(unescape('%u000g0'), '%u000g0');
assertSameValue(unescape('%u000G0'), '%u000G0');
assertSameValue(unescape('%u00g00'), '%u00g00');
assertSameValue(unescape('%u00G00'), '%u00G00');
assertSameValue(unescape('%u0g000'), '%u0g000');
assertSameValue(unescape('%u0G000'), '%u0G000');
assertSameValue(unescape('%ug0000'), '%ug0000');
assertSameValue(unescape('%uG0000'), '%uG0000');

assertSameValue(unescape('%u000u0'), '%u000u0');
assertSameValue(unescape('%u000U0'), '%u000U0');
assertSameValue(unescape('%u00u00'), '%u00u00');
assertSameValue(unescape('%u00U00'), '%u00U00');
assertSameValue(unescape('%u0u000'), '%u0u000');
assertSameValue(unescape('%u0U000'), '%u0U000');
assertSameValue(unescape('%uu0000'), '%uu0000');
assertSameValue(unescape('%uU0000'), '%uU0000');
}
