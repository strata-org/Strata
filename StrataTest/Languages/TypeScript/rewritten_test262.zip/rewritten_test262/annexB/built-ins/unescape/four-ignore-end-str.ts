// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2016 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-unescape-string
es6id: B.2.1.2
description: >
    Does not transform four-character patterns that are interrupted by the end
    of the string
info: |
    [...]
    5. Repeat, while k ≠ length,
       [...]
       a. Let c be the code unit at index k within string.
       b. If c is %, then
          i. If k ≤ length-6 and the code unit at index k+1 within string is u
             and the four code units at indices k+2, k+3, k+4, and k+5 within
             string are all hexadecimal digits, then
             1. Let c be the code unit whose value is the integer represented
                by the four hexadecimal digits at indices k+2, k+3, k+4, and
                k+5 within string.
             2. Increase k by 5.
       [...]
---*/

assertSameValue(unescape('%u'), '%u');

assertSameValue(unescape('%u0'), '%u0');
assertSameValue(unescape('%u1'), '%u1');
assertSameValue(unescape('%u2'), '%u2');
assertSameValue(unescape('%u3'), '%u3');
assertSameValue(unescape('%u4'), '%u4');
assertSameValue(unescape('%u5'), '%u5');
assertSameValue(unescape('%u6'), '%u6');
assertSameValue(unescape('%u7'), '%u7');
assertSameValue(unescape('%u8'), '%u8');
assertSameValue(unescape('%u9'), '%u9');
assertSameValue(unescape('%ua'), '%ua');
assertSameValue(unescape('%uA'), '%uA');
assertSameValue(unescape('%ub'), '%ub');
assertSameValue(unescape('%uB'), '%uB');
assertSameValue(unescape('%uc'), '%uc');
assertSameValue(unescape('%uC'), '%uC');
assertSameValue(unescape('%ud'), '%ud');
assertSameValue(unescape('%uD'), '%uD');
assertSameValue(unescape('%ue'), '%ue');
assertSameValue(unescape('%uE'), '%uE');
assertSameValue(unescape('%uf'), '%uf');
assertSameValue(unescape('%uF'), '%uF');

assertSameValue(unescape('%u00'), '%u00');
assertSameValue(unescape('%u01'), '%u01');
assertSameValue(unescape('%u02'), '%u02');
assertSameValue(unescape('%u03'), '%u03');
assertSameValue(unescape('%u04'), '%u04');
assertSameValue(unescape('%u05'), '%u05');
assertSameValue(unescape('%u06'), '%u06');
assertSameValue(unescape('%u07'), '%u07');
assertSameValue(unescape('%u08'), '%u08');
assertSameValue(unescape('%u09'), '%u09');
assertSameValue(unescape('%u0a'), '%u0a');
assertSameValue(unescape('%u0A'), '%u0A');
assertSameValue(unescape('%u0b'), '%u0b');
assertSameValue(unescape('%u0B'), '%u0B');
assertSameValue(unescape('%u0c'), '%u0c');
assertSameValue(unescape('%u0C'), '%u0C');
assertSameValue(unescape('%u0d'), '%u0d');
assertSameValue(unescape('%u0D'), '%u0D');
assertSameValue(unescape('%u0e'), '%u0e');
assertSameValue(unescape('%u0E'), '%u0E');
assertSameValue(unescape('%u0f'), '%u0f');
assertSameValue(unescape('%u0F'), '%u0F');

assertSameValue(unescape('%u000'), '%u000');
assertSameValue(unescape('%u001'), '%u001');
assertSameValue(unescape('%u002'), '%u002');
assertSameValue(unescape('%u003'), '%u003');
assertSameValue(unescape('%u004'), '%u004');
assertSameValue(unescape('%u005'), '%u005');
assertSameValue(unescape('%u006'), '%u006');
assertSameValue(unescape('%u007'), '%u007');
assertSameValue(unescape('%u008'), '%u008');
assertSameValue(unescape('%u009'), '%u009');
assertSameValue(unescape('%u00a'), '%u00a');
assertSameValue(unescape('%u00A'), '%u00A');
assertSameValue(unescape('%u00b'), '%u00b');
assertSameValue(unescape('%u00B'), '%u00B');
assertSameValue(unescape('%u00c'), '%u00c');
assertSameValue(unescape('%u00C'), '%u00C');
assertSameValue(unescape('%u00d'), '%u00d');
assertSameValue(unescape('%u00D'), '%u00D');
assertSameValue(unescape('%u00e'), '%u00e');
assertSameValue(unescape('%u00E'), '%u00E');
assertSameValue(unescape('%u00f'), '%u00f');
assertSameValue(unescape('%u00F'), '%u00F');
}
