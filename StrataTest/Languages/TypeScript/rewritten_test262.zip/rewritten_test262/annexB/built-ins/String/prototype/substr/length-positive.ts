// Copyright (C) 2017 Ecma International.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
description: |
    Collection of assertion functions used throughout test262
defines: [assert]
---*/

var __errorCount = 0;

function assert(mustBeTrue, message) {
  if (mustBeTrue === true) {
    return;
  }

  if (message === undefined) {
    message = 'Expected true but got something else: ' + mustBeTrue.toString();
  }
  __errorCount++;
}

function _isSameValue(a, b) {
  if (a === b) {
    // Handle +/-0 vs. -/+0
    return a !== 0 || 1 / a === 1 / b;
  }

  // Handle NaN vs. NaN
  return a !== a && b !== b;
};

function assertSameValue(actual, expected, message) {
  if (!_isSameValue(actual, expected)) {
    __errorCount++;
  }
}


function assertNotSameValue (actual, unexpected, message) {
  if (_isSameValue(actual, unexpected)) {
    __errorCount++;
  } 
};

function assertThrows(expectedErrorConstructor, func, message) {
  var expectedName, actualName;
  if (typeof func !== "function") {
    __errorCount++;
    return;
  }
  if (message === undefined) {
    message = '';
  } else {
    message += ' ';
  }

  try {
    func();
  } catch (thrown) {
    if (typeof thrown !== 'object' || thrown === null) {
      __errorCount++;
    } else if (thrown.constructor !== expectedErrorConstructor) {
      __errorCount++;
    }
    return;
  }

  __errorCount++;
};




function run() {
// Copyright (C) 2016 the V8 project authors. All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.
/*---
esid: sec-string.prototype.substr
es6id: B.2.3.1
description: Behavior when "length" is a positive number
info: |
    [...]
    4. If length is undefined, let end be +∞; otherwise let end be ?
       ToInteger(length).
    [...]
    7. Let resultLength be min(max(end, 0), size - intStart).
    8. If resultLength ≤ 0, return the empty String "".
    9. Return a String containing resultLength consecutive code units from S
       beginning with the code unit at index intStart.
---*/

assertSameValue('abc'.substr(0, 1), 'a', '0, 1');
assertSameValue('abc'.substr(0, 2), 'ab', '0, 1');
assertSameValue('abc'.substr(0, 3), 'abc', '0, 1');
assertSameValue('abc'.substr(0, 4), 'abc', '0, 1');

assertSameValue('abc'.substr(1, 1), 'b', '1, 1');
assertSameValue('abc'.substr(1, 2), 'bc', '1, 1');
assertSameValue('abc'.substr(1, 3), 'bc', '1, 1');
assertSameValue('abc'.substr(1, 4), 'bc', '1, 1');

assertSameValue('abc'.substr(2, 1), 'c', '2, 1');
assertSameValue('abc'.substr(2, 2), 'c', '2, 1');
assertSameValue('abc'.substr(2, 3), 'c', '2, 1');
assertSameValue('abc'.substr(2, 4), 'c', '2, 1');

assertSameValue('abc'.substr(3, 1), '', '3, 1');
assertSameValue('abc'.substr(3, 2), '', '3, 1');
assertSameValue('abc'.substr(3, 3), '', '3, 1');
assertSameValue('abc'.substr(3, 4), '', '3, 1');
}
